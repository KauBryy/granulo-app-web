import logging
import voluptuous as vol
from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.config_entries import ConfigEntry
from homeassistant.helpers.dispatcher import async_dispatcher_send
import homeassistant.helpers.config_validation as cv
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

# Schéma étendu pour les services
SERVICE_SCHEMA = vol.Schema({
    vol.Optional("amount", default=1.0): vol.Coerce(float),
    vol.Optional("note", default="Ajouté via Home Assistant"): cv.string,
    vol.Optional("price", default=0.0): vol.Coerce(float),
})

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Configuration de l'intégration Granulo."""
    hass.data.setdefault(DOMAIN, {})

    # On enregistre la plateforme sensor
    await hass.config_entries.async_forward_entry_setups(entry, ["sensor"])

    # --- SERVICES ---
    async def handle_add_data(call: ServiceCall):
        amount = call.data.get("amount", 1.0)
        note = call.data.get("note", "Ajouté via Home Assistant")
        price = call.data.get("price", 0.0)

        # On envoie un événement sur le bus HA
        hass.bus.async_fire("granulo_action", {
            "action": call.service,
            "amount": amount,
            "note": note,
            "price": price,
        })
        
        # Petit message de confirmation dans les logs de HA
        _LOGGER.info(f"Granulo: Action envoyée vers l'app -> {call.service} ({amount} sacs, {price}€, Note: {note})")
        
        # On crée une notification persistante dans HA proprement
        await hass.services.async_call(
            "persistent_notification",
            "create",
            {
                "title": "Granulo Sync",
                "message": f"Commande envoyée à Granulo : {amount} sac(s) ({'Achat' if 'purchase' in call.service else 'Brûlage'})",
                "notification_id": "granulo_sync"
            }
        )

    hass.services.async_register(DOMAIN, "add_burn", handle_add_data, schema=SERVICE_SCHEMA)
    hass.services.async_register(DOMAIN, "add_purchase", handle_add_data, schema=SERVICE_SCHEMA)

    return True

async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Suppression de l'intégration Granulo."""
    hass.services.async_remove(DOMAIN, "add_burn")
    hass.services.async_remove(DOMAIN, "add_purchase")
    return await hass.config_entries.async_unload_platforms(entry, ["sensor"])
