from homeassistant.core import HomeAssistant, Event, ServiceCall
from homeassistant.config_entries import ConfigEntry
from homeassistant.helpers.dispatcher import async_dispatcher_send
import homeassistant.helpers.config_validation as cv
import voluptuous as vol
import json
from .const import DOMAIN

# Schéma pour les services
SERVICE_SCHEMA = vol.Schema({
    vol.Optional("amount", default=1.0): vol.Coerce(float),
})

DASHBOARD_CONFIG = {
    "views": [
        {
            "title": "Granulo",
            "icon": "mdi:fire",
            "cards": [
                {
                    "type": "vertical-stack",
                    "cards": [
                        {
                            "type": "grid",
                            "columns": 2,
                            "square": false,
                            "cards": [
                                {"type": "sensor", "entity": "sensor.granulo_stock", "name": "Stock Actuel", "graph": "line"},
                                {"type": "sensor", "entity": "sensor.granulo_autonomie", "name": "Jours Restants"}
                            ]
                        },
                        {
                            "type": "entities",
                            "title": "Statistiques",
                            "entities": [
                                {"entity": "sensor.granulo_moyenne_7j", "name": "Moyenne 7 jours"},
                                {"entity": "sensor.granulo_achat_saison", "name": "Sacs Achetés"},
                                {"entity": "sensor.granulo_brulage_saison", "name": "Sacs Brûlés"}
                            ]
                        },
                        {
                            "type": "horizontal-stack",
                            "cards": [
                                {
                                    "type": "button",
                                    "name": "Ajouter Achat",
                                    "icon": "mdi:cart-plus",
                                    "tap_action": {"action": "call-service", "service": "granulo.add_purchase", "data": {"amount": 1}}
                                },
                                {
                                    "type": "button",
                                    "name": "Ajouter Brûlage",
                                    "icon": "mdi:fire",
                                    "tap_action": {"action": "call-service", "service": "granulo.add_burn", "data": {"amount": 1}}
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
}

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Configuration de l'intégration Granulo."""
    hass.data.setdefault(DOMAIN, {})

    # On enregistre la plateforme sensor
    await hass.config_entries.async_forward_entry_setups(entry, ["sensor"])

    # --- TENTATIVE DE CRÉATION AUTOMATIQUE DU DASHBOARD ---
    async def create_granulo_dashboard():
        try:
            # On vérifie si le dashboard existe déjà dans les ressources Lovelace
            lovelace = hass.data.get("lovelace")
            if lovelace and hasattr(lovelace, "async_get_dashboards"):
                dashboards = await lovelace.async_get_dashboards()
                if not any(d.get("url_path") == "granulo" for d in dashboards):
                    # On crée la ressource dashboard
                    await lovelace.async_create_dashboard("granulo", "Granulo", "mdi:fire", False, True)
                    # On injecte la config
                    await lovelace.async_save_config("granulo", DASHBOARD_CONFIG)
                    _LOGGER.info("Granulo: Dashboard créé automatiquement ! 🚀")
        except Exception as e:
            _LOGGER.warning(f"Granulo: Impossible de créer le dashboard automatiquement: {e}")

    # On lance la création en tâche de fond
    hass.async_create_task(create_granulo_dashboard())

    # --- SERVICES ---
    async def handle_add_data(call: ServiceCall):
        amount = call.data.get("amount", 1.0)
        hass.bus.async_fire("granulo_action", {
            "action": call.service,
            "amount": amount,
            "timestamp": hass.datetime.now().isoformat()
        })

    hass.services.async_register(DOMAIN, "add_burn", handle_add_data, schema=SERVICE_SCHEMA)
    hass.services.async_register(DOMAIN, "add_purchase", handle_add_data, schema=SERVICE_SCHEMA)

    # --- ÉCOUTEUR ---
    async def handle_granulo_update(event: Event):
        async_dispatcher_send(hass, f"{DOMAIN}_update_{entry.entry_id}", event.data)

    entry.async_on_unload(hass.bus.async_listen("granulo_update", handle_granulo_update))

    return True

async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Suppression de l'intégration Granulo."""
    hass.services.async_remove(DOMAIN, "add_burn")
    hass.services.async_remove(DOMAIN, "add_purchase")
    return await hass.config_entries.async_unload_platforms(entry, ["sensor"])

