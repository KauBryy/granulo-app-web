import logging
from homeassistant.core import HomeAssistant, Event, ServiceCall
from homeassistant.config_entries import ConfigEntry
from homeassistant.helpers.dispatcher import async_dispatcher_send
import homeassistant.helpers.config_validation as cv
import voluptuous as vol
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

# Schéma pour les services
SERVICE_SCHEMA = vol.Schema({
    vol.Optional("amount", default=1.0): vol.Coerce(float),
})

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Configuration de l'intégration Granulo."""
    hass.data.setdefault(DOMAIN, {})

    # On enregistre la plateforme sensor
    await hass.config_entries.async_forward_entry_setups(entry, ["sensor"])

    # --- SERVICES ---
    async def handle_add_data(call: ServiceCall):
        amount = call.data.get("amount", 1.0)
        # On envoie un événement sur le bus HA
        # L'app mobile pourra écouter ces événements si besoin, 
        # mais ici on simule l'action
        hass.bus.async_fire("granulo_action", {
            "action": call.service,
            "amount": amount,
        })
        _LOGGER.info(f"Granulo action reçue: {call.service} avec {amount}")

    hass.services.async_register(DOMAIN, "add_burn", handle_add_data, schema=SERVICE_SCHEMA)
    hass.services.async_register(DOMAIN, "add_purchase", handle_add_data, schema=SERVICE_SCHEMA)

    # --- ÉCOUTEUR ---
    # Permet de recevoir des mises à jour globales si nécessaire
    async def handle_granulo_update(event: Event):
        async_dispatcher_send(hass, f"{DOMAIN}_update_{entry.entry_id}", event.data)

    entry.async_on_unload(hass.bus.async_listen("granulo_update", handle_granulo_update))

    return True

async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Suppression de l'intégration Granulo."""
    hass.services.async_remove(DOMAIN, "add_burn")
    hass.services.async_remove(DOMAIN, "add_purchase")
    return await hass.config_entries.async_unload_platforms(entry, ["sensor"])
