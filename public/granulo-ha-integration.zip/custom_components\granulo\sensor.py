import logging
import async_timeout
import aiohttp
from datetime import timedelta
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed
from homeassistant.components.sensor import SensorEntity
from homeassistant.helpers.entity import DeviceInfo
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

SCAN_INTERVAL = timedelta(minutes=15)
PROJECT_ID = "granulo-446e4"
API_KEY = "AIzaSyCmHG_v4ymxmkNRiKc3dU7PnIl_dV89u4c"

async def async_setup_entry(hass, entry, async_add_entities):
    """Configuration des capteurs Granulo depuis Firebase."""
    user_id = entry.data.get("user_id")
    
    coordinator = GranuloDataCoordinator(hass, user_id)
    await coordinator.async_config_entry_first_refresh()

    sensors = [
        GranuloSensor(coordinator, "stock", "Stock Actuel", "sacs", "mdi:package-variant"),
        GranuloSensor(coordinator, "totalSacksPurchased", "Achats Total", "sacs", "mdi:archive-arrow-down"),
        GranuloSensor(coordinator, "totalSacksBurned", "Brûlages Total", "sacs", "mdi:fire-alert"),
        GranuloSensor(coordinator, "totalCost", "Dépenses Total", "€", "mdi:cash-lock"),
        GranuloSensor(coordinator, "currentStockWeight", "Stock (kg)", "kg", "mdi:weight-kilogram"),
    ]
    
    async_add_entities(sensors)

class GranuloDataCoordinator(DataUpdateCoordinator):
    """Coordinateur pour interroger Firestore REST API."""

    def __init__(self, hass, user_id):
        super().__init__(hass, _LOGGER, name=DOMAIN, update_interval=SCAN_INTERVAL)
        self.user_id = user_id

    async def _async_update_data(self):
        """Récupère les données depuis Firestore."""
        from datetime import datetime
        year = datetime.now().year
        url = f"https://firestore.googleapis.com/v1/projects/{PROJECT_ID}/databases/(default)/documents/users/{self.user_id}/aggregates/year_{year}?key={API_KEY}"

        try:
            async with async_timeout.timeout(10):
                async with aiohttp.ClientSession() as session:
                    async with session.get(url) as response:
                        if response.status == 404:
                            _LOGGER.warning(f"Granulo: Document d'agrégation non trouvé pour l'année {year}")
                            return {}
                        if response.status != 200:
                            raise UpdateFailed(f"Erreur Firestore: {response.status}")
                        
                        data = await response.json()
                        fields = data.get("fields", {})
                        
                        # Extraction simplifiée des valeurs Firestore
                        result = {}
                        for key, val in fields.items():
                            if "doubleValue" in val:
                                result[key] = float(val["doubleValue"])
                            elif "integerValue" in val:
                                result[key] = int(val["integerValue"])
                        
                        return result
        except Exception as e:
            raise UpdateFailed(f"Erreur de connexion Firestore: {e}")

class GranuloSensor(SensorEntity):
    """Représentation d'un capteur Granulo."""

    def __init__(self, coordinator, key, name, unit, icon):
        self.coordinator = coordinator
        self._key = key
        self._name = name
        self._unit = unit
        self._icon = icon

    @property
    def name(self):
        return f"Granulo {self._name}"

    @property
    def unique_id(self):
        return f"granulo_{self.coordinator.user_id}_{self._key}"

    @property
    def state(self):
        # Pour le stock, si on n'a pas le champ calculé, on le calcule
        if self._key == "stock":
            achats = self.coordinator.data.get("totalSacksPurchased", 0)
            brulages = self.coordinator.data.get("totalSacksBurned", 0)
            return round(achats - brulages, 1)
        
        return self.coordinator.data.get(self._key, 0)

    @property
    def unit_of_measurement(self):
        return self._unit

    @property
    def icon(self):
        return self._icon

    @property
    def device_info(self):
        return DeviceInfo(
            identifiers={(DOMAIN, self.coordinator.user_id)},
            name="Poêle Granulo",
            manufacturer="Granulo App",
            model="Expert Mode",
        )

    @property
    def should_poll(self):
        return False

    async def async_added_to_hass(self):
        self.async_on_remove(self.coordinator.async_add_listener(self.async_write_ha_state))
